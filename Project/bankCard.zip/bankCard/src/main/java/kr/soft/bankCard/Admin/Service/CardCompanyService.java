package kr.soft.bankCard.Admin.Service;

import kr.soft.bankCard.VO.CardCompanyVO;

import java.util.List;

public interface CardCompanyService {

    List<CardCompanyVO> selectCardCompanyList();
}
