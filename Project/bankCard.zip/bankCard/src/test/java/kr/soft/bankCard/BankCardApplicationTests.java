package kr.soft.bankCard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankCardApplicationTests {

	@Test
	void contextLoads() {
	
		System.out.println("test");


	}
	
	

}
